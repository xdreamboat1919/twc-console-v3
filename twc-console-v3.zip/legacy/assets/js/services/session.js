/* ================= SESSION ================= */
var FIELDS=['n-geo','n-prod','n-fun','n-pur','n-bud','n-gate','n-asn','n-aud','n-asd',
 'c-date','c-project','c-family','c-id','c-source','c-format','c-style','c-message','c-hook','c-group','c-gender','c-age','c-length','c-placement','c-version','c-claim','u-url','u-src','u-med','u-term',
 's-lane','s-geo','s-day','s-phase','s-assets','b-day','b-cpa','b-sets','p-plan','p-spent','p-day','p-dim',
 'e-price','e-cogs','e-ship','e-fee','e-roas','e-aov','e-ltv','m-s1','m-c1','m-s2','m-c2',
 'cr-batch','cr-cpa','cr-mult','cr-batc','cr-bic','cc-in','rc-mp','rc-mr','rc-sp','rc-sr',
 'fg-freq','fg-ctr1','fg-ctr2','fg-cpm1','fg-cpm2','fg-days',
 'tr-url','tr-phi','tr-name','ev-in','es-sel','fn-1','fn-2','fn-3','fn-4','fn-5','fn-6','fn-7','fn-8','fn-9','fn-cpi',
 'ic-n1','ic-a1','ic-f1','ic-r1','ic-n2','ic-a2','ic-f2','ic-r2','ic-n3','ic-a3','ic-f3','ic-r3','ic-n4','ic-a4','ic-f4','ic-r4',
 'lv-aov','lv-mar','lv-freq','lv-hor','lv-rl','lv-re','lv-rh','lv-mem','cc-spend','cc-new','cc-all','cc-other',
 'sg-tot','sg-rep','sg-act','sg-hv','sg-sel','sh-sel','sh-so','sh-sr','sh-tag','sh-meta',
 'fc-day','fc-cpa','fc-floor','fc-imp','fc-aov','fc-l2','fc-l3','fc-pen',
 'rp-wk','rp-sp','rp-rv','rp-pu','rp-psp','rp-prv','rp-ppu','rp-tgt','rp-new','rp-dis','rp-grad','rp-be',
 'of-price','of-mar','of-disc','of-lift','mr-rev','mr-spend','mr-meta','mr-mspend',
 'st-c1','st-n1','st-c2','st-n2','sa-size','sa-reach','sa-freq','sa-days',
 'co-n1','co-a1','co-b1','co-n2','co-a2','co-b2','co-n3','co-a3','co-b3','co-n4','co-a4','co-b4','co-n5','co-a5','co-b5','co-n6','co-a6','co-b6',
 'rf-gross','rf-ref','rf-cb','rf-unf','rf-spend','sb-act','sb-new','sb-vol','sb-inv','sb-val','sb-rec',
 'gp-a1','gp-m1','gp-r1','gp-c1','gp-a2','gp-m2','gp-r2','gp-c2','gp-a3','gp-m3','gp-r3','gp-c3','gp-a4','gp-m4','gp-r4','gp-c4','gp-a5','gp-m5','gp-r5','gp-c5',
 'cf-s','cf-p','cf-c','cf-k','cf-o','sc-sel','sp-s0','sp-c0','sp-s1','sp-k','sp-max','sp-aov','lk-sel',
 'at-n','at-click','at-buy','at-win','aw-1c','aw-7c','aw-7c1v','aw-be','aw-sp','aw-aov',
 'ak-sp','ak-cv','ak-tgt','ak-ctr','ak-share','ak-trend','ak-days','ak-stage',
 'ai-sp','ai-roas','ai-hold','ai-wk','ai-inc',
 'ps-ord','ps-rr','ps-meta','ps-goog','ps-wom','ps-oth','ps-plat','ps-sp',
 'of2-v0','of2-m0','of2-v1','of2-t1','of2-m1','of2-v2','of2-t2','of2-m2','of2-v3','of2-t3','of2-m3','of2-v4','of2-t4','of2-m4',
 'ch-s1','ch-r1','ch-e1','ch-s2','ch-r2','ch-e2','ch-s3','ch-r3','ch-e3','ch-s4','ch-r4','ch-e4','ch-s5','ch-r5','ch-e5','ch-add','ch-min','pf-lane',
 'sd-s0','sd-s1','sd-c0','sd-c1','sd-days','sd-m0','sd-m1','sd-f1','sd-t0','sd-t1','sd-learn','sd-be',
 'dd-1','dd-2','dd-3','dd-4','dd-5','dd-6','dd-7','dd-8','cs-sp','cs-cpm','cs-aud','cs-tol',
 'sc2-n','sc2-ov','sc2-sp','sc2-same','rd-sp','rd-n','rd-new','rd-days','rd-cpa','rd-inc',
 'cq-imp','cq-3s','cq-tp','cq-clk','cq-lpv','cq-pur','cq-fmt','cq-stage',
 'rr-sp','rr-imp','rr-clk','rr-cv','rr-days','rr-cpa',
 'ct-stage2','ct-day','ct-cpa','ct-prod','ct-assets','px-spec',
 'bd-p0s','bd-p0o','bd-p0r','bd-p1s','bd-p1o','bd-p1r',
 'bd-r0s','bd-r0o','bd-r0r','bd-r1s','bd-r1o','bd-r1r',
 'bd-e0s','bd-e0o','bd-e0r','bd-e1s','bd-e1o','bd-e1r',
 'ba-rev','ba-ret','ba-sub','ba-sp','ba-new','ba-mo','mk-sel',
 'lk-src','lk-size','lk-rec','lk-val','lk-geo','lk-pct','st2-a','st2-b','st2-x',
 'ex-type','ex-lane','ex-tier','ex-geo',
 'gb-sp','gb-cv','gb-aov','gb-org','gb-can','gb-comp','gs-type','gs-lane','gs-day','gs-cpa',
 'gw-s1','gw-c1','gw-s2','gw-c2','gw-s3','gw-c3','gw-s4','gw-c4','gw-s5','gw-c5','gi-is','gi-bud','gi-rank','gi-sp','gi-cpa','gi-max',
 'rv-s0','rv-a0','rv-i0','rv-p0','rv-s1','rv-a1','rv-i1','rv-p1','bk-dim',
 'in-d0','in-i0','in-d1','in-i1','in-sp','in-aov',
 'xt-test-type','xt-test-mode','xt-budget','xt-split','xt-audience-control','xt-placement-control','xt-winner-rule','xt-stop-loss','xt-compliance-gate','xt-baseline-rate','xt-mde','xt-confidence-target','xt-control-visitors','xt-control-conversions','xt-variant-visitors','xt-variant-conversions',
 'gl-production-capacity','gl-refresh-days','gl-portfolio-budget'];

function captureSessionState(){
  return {v:9,fields:TWC.dataSource.captureFields(FIELDS),creatives:creatives,checked:checked,rtDone:rtDone,wfDone:wfDone,
    lkDone:lkDone,pfDone:pfDone,comp:COMP,pxOn:pxOn,pqOn:pqOn,
    dailyRecords:dailyRecords,optimizationActions:optimizationActions,changeRecords:changeRecords,experimentRecords:experimentRecords,
    scaleCandidates:scaleCandidates,scaleSteps:scaleSteps,creativeIdeas:creativeIdeas,creativeAssets:creativeAssets,
    workspaceState:typeof workspaceState==='undefined'?null:workspaceState};
}
function applySessionState(d){
  if(!d||typeof d!=='object')throw new Error('Invalid console session');
  if(d.fields)TWC.dataSource.applyFields(FIELDS,d.fields);
  creatives=Array.isArray(d.creatives)?d.creatives:[];checked=d.checked||{};rtDone=d.rtDone||{};
  wfDone=d.wfDone||{};lkDone=d.lkDone||{};pfDone=d.pfDone||{};
  dailyRecords=Array.isArray(d.dailyRecords)?d.dailyRecords:[];
  optimizationActions=Array.isArray(d.optimizationActions)?d.optimizationActions:[];
  changeRecords=Array.isArray(d.changeRecords)?d.changeRecords:[];
  experimentRecords=Array.isArray(d.experimentRecords)?d.experimentRecords:[];
  scaleCandidates=Array.isArray(d.scaleCandidates)?d.scaleCandidates:[];
  scaleSteps=Array.isArray(d.scaleSteps)?d.scaleSteps:[];
  creativeIdeas=Array.isArray(d.creativeIdeas)?d.creativeIdeas:[];
  creativeAssets=Array.isArray(d.creativeAssets)?d.creativeAssets:[];
  if(d.pxOn)pxOn=d.pxOn;if(d.pqOn)pqOn=d.pqOn;
  if(d.comp){COMP.length=0;d.comp.forEach(function(c){COMP.push(c)})}
  if(d.workspaceState&&typeof workspaceState!=='undefined')workspaceState=workspaceMigrate(d.workspaceState);
}

$('save').addEventListener('click',function(){
  var d=captureSessionState();
  dl(new Blob([JSON.stringify(d,null,2)],{type:'application/json'}),'twc-console-'+new Date().toISOString().slice(0,10)+'.json');
  if(TWC.store)TWC.store.saveNow('session export');
  toast('Session exported and workspace saved');
});
$('load').addEventListener('click',function(){$('file').click()});
$('file').addEventListener('change',function(e){
  var f=e.target.files[0]; if(!f)return;
  var r=new FileReader();
  r.onload=function(){
    try{
      var d=JSON.parse(r.result);applySessionState(d);
      renderAll();if(typeof renderProductionAll==='function')renderProductionAll();
      if(TWC.store)TWC.store.saveNow('session import');toast('Session imported and saved');
    }catch(err){alert('That file could not be read as a console session.')}
  };
  r.readAsText(f); e.target.value='';
});
